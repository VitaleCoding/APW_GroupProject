//Still a WIP but with these examples it should be shown what I'm planning. I might split the questions and answers into two different files
//but we'll have to see after we've all met again
var quizQuestions = [
    {
        question: "What is the capital of France?",
        options: ["London", "Paris", "Berlin", "Rome"],
        correctAnswer: "Paris"
    },
    {
        question: "Which planet is known as the Red Planet?",
        options: ["Venus", "Mars", "Jupiter", "Saturn"],
        correctAnswer: "Mars"
    },
    // Add more questions here -- WIP
];